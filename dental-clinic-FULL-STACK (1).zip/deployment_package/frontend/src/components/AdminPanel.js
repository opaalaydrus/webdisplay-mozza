import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';
import { Users, UserCheck, Upload, Trash2, Eye, X, RotateCcw, ExternalLink } from 'lucide-react';

// Configure axios to prevent browser auth popup
axios.defaults.withCredentials = false;

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Create an axios interceptor to automatically add JWT tokens to requests
axios.interceptors.request.use(
  (config) => {
    // Only add Authorization header for API requests
    if (config.url && config.url.includes('/api/')) {
      const tokenData = localStorage.getItem('dental_admin_tokens');
      if (tokenData) {
        try {
          const tokens = JSON.parse(tokenData);
          if (tokens.access_token) {
            config.headers.Authorization = `Bearer ${tokens.access_token}`;
            console.log('Axios interceptor: Added Authorization header');
          }
        } catch (error) {
          console.error('Axios interceptor: Error parsing tokens', error);
        }
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const AdminPanel = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authCredentials, setAuthCredentials] = useState({ username: '', password: '' });
  const [authError, setAuthError] = useState('');
  const [tokenData, setTokenData] = useState(null);
  
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState('sako');
  
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [nurses, setNurses] = useState([]);
  const [liveState, setLiveState] = useState({});
  
  const [loading, setLoading] = useState({});
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [socket, setSocket] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');

  // Token refresh synchronization
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshPromise, setRefreshPromise] = useState(null);

  // JWT Token Management
  useEffect(() => {
    const savedTokenData = localStorage.getItem('dental_admin_tokens');
    if (savedTokenData && !isAuthenticated) {
      try {
        const tokens = JSON.parse(savedTokenData);
        // Check if access token is still valid (basic check)
        if (tokens.access_token && tokens.expires_at > Date.now()) {
          console.log('Valid tokens found, attempting auto-login');
          setTokenData(tokens);
          testStoredTokens(tokens);
        } else if (tokens.refresh_token) {
          console.log('Access token expired, attempting refresh');
          refreshAccessToken(tokens.refresh_token);
        } else {
          console.log('No valid tokens found');
          localStorage.removeItem('dental_admin_tokens');
        }
      } catch (error) {
        console.error('Error parsing stored tokens:', error);
        localStorage.removeItem('dental_admin_tokens');
      }
    }
  }, []);

  const testStoredTokens = async (tokens) => {
    try {
      const response = await axios.get(`${API}/auth/me`, {
        headers: {
          'Authorization': `Bearer ${tokens.access_token}`
        }
      });
      
      if (response.status === 200) {
        console.log('Stored tokens valid, auto-login successful');
        setIsAuthenticated(true);
        setTokenData(tokens);
        setAuthError(''); // Clear any auth errors
        return true;
      }
    } catch (error) {
      console.log('Auto-login failed:', error.message);
      if (tokens.refresh_token) {
        console.log('Attempting to refresh expired token...');
        return await refreshAccessToken(tokens.refresh_token);
      }
      console.log('No refresh token available, clearing storage');
      localStorage.removeItem('dental_admin_tokens');
      return false;
    }
  };

  const refreshAccessToken = async (refreshToken) => {
    // If already refreshing, wait for the existing refresh to complete
    if (isRefreshing && refreshPromise) {
      console.log('Token refresh already in progress, waiting...');
      return await refreshPromise;
    }

    // Start new refresh process
    setIsRefreshing(true);
    
    const refresh = async () => {
      try {
        console.log('Refreshing access token...');
        const response = await axios.post(`${API}/auth/refresh`, {
          refresh_token: refreshToken
        });
        
        if (response.status === 200) {
          const newTokens = {
            access_token: response.data.access_token,
            refresh_token: response.data.refresh_token,
            expires_at: Date.now() + (response.data.expires_in * 1000)
          };
          
          localStorage.setItem('dental_admin_tokens', JSON.stringify(newTokens));
          setTokenData(newTokens);
          setIsAuthenticated(true);
          setAuthError(''); // Clear any auth errors
          console.log('Token refresh successful, new expiry:', new Date(newTokens.expires_at).toISOString());
          return true;
        } else {
          console.error('Token refresh failed with status:', response.status);
          localStorage.removeItem('dental_admin_tokens');
          setTokenData(null);
          setIsAuthenticated(false);
          return false;
        }
      } catch (error) {
        console.error('Token refresh failed:', error);
        localStorage.removeItem('dental_admin_tokens');
        setTokenData(null);
        setIsAuthenticated(false);
        setAuthError('Session expired. Please login again.');
        return false;
      } finally {
        setIsRefreshing(false);
        setRefreshPromise(null);
      }
    };

    const promise = refresh();
    setRefreshPromise(promise);
    return await promise;
  };

  const logout = async () => {
    try {
      if (tokenData) {
        // Call logout endpoint
        await axios.post(`${API}/auth/logout`, {}, {
          headers: {
            'Authorization': `Bearer ${tokenData.access_token}`
          }
        });
      }
    } catch (error) {
      console.log('Logout API call failed:', error.message);
    }
    
    // Clear local state
    setIsAuthenticated(false);
    setAuthCredentials({ username: '', password: '' });
    setTokenData(null);
    localStorage.removeItem('dental_admin_tokens');
    
    if (socket) {
      socket.disconnect();
    }
  };

  // Forms
  const [patientForm, setPatientForm] = useState({ name: '', note: '' });
  const [doctorForm, setDoctorForm] = useState({ name: '' });
  const [nurseForm, setNurseForm] = useState({ name: '' });
  const [musicForm, setMusicForm] = useState({ youtubeUrl: '', muted: true });

  useEffect(() => {
    if (isAuthenticated) {
      loadData();
      initializeSocket();
    }
    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, [isAuthenticated, selectedLocation]);

  // Auto-refresh token before expiry
  useEffect(() => {
    if (!isAuthenticated || !tokenData) return;
    
    const checkTokenExpiry = () => {
      const timeUntilExpiry = tokenData.expires_at - Date.now();
      const refreshThreshold = 5 * 60 * 1000; // 5 minutes before expiry
      
      if (timeUntilExpiry <= refreshThreshold && timeUntilExpiry > 0) {
        console.log('Token expiring soon, refreshing...');
        refreshAccessToken(tokenData.refresh_token);
      } else if (timeUntilExpiry <= 0) {
        console.log('Token expired, logging out');
        logout();
      }
    };
    
    // Check immediately
    checkTokenExpiry();
    
    // Check every minute
    const interval = setInterval(checkTokenExpiry, 60000);
    
    return () => clearInterval(interval);
  }, [isAuthenticated, tokenData]);

  const initializeSocket = () => {
    const newSocket = io(BACKEND_URL, {
      transports: ['websocket', 'polling']
    });

    newSocket.on('connect', () => {
      setConnectionStatus('connected');
      newSocket.emit('join_room', { locationSlug: selectedLocation });
    });

    newSocket.on('disconnect', () => {
      setConnectionStatus('disconnected');
    });

    newSocket.on('live:init', (data) => {
      setLiveState(data);
    });

    newSocket.on('live:update', (data) => {
      setLiveState(data);
      setSuccess('Display updated successfully!');
      setTimeout(() => setSuccess(''), 3000);
    });

    setSocket(newSocket);
  };

  const authenticate = async (e) => {
    e.preventDefault();
    setAuthError('');
    setLoading(prev => ({ ...prev, login: true }));
    
    try {
      const response = await axios.post(`${API}/auth/login`, {
        username: authCredentials.username,
        password: authCredentials.password
      });
      
      if (response.status === 200) {
        const tokens = {
          access_token: response.data.access_token,
          refresh_token: response.data.refresh_token,
          expires_at: Date.now() + (response.data.expires_in * 1000)
        };
        
        // Store tokens securely
        localStorage.setItem('dental_admin_tokens', JSON.stringify(tokens));
        setTokenData(tokens);
        setIsAuthenticated(true);
        setAuthError(''); // Clear any previous auth errors
        console.log('Login successful, token expires at:', new Date(tokens.expires_at).toISOString());
        
        // Don't call loadData immediately, let the useEffect handle it
      } else {
        setAuthError('Invalid credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      if (error.response?.status === 401) {
        setAuthError('Invalid credentials');
      } else {
        setAuthError('Login failed. Please try again.');
      }
    } finally {
      setLoading(prev => ({ ...prev, login: false }));
    }
  };

  const apiCall = async (method, url, data = null, config = {}, retryCount = 0) => {
    // Wait if token refresh is in progress
    if (isRefreshing && refreshPromise) {
      console.log('Waiting for token refresh to complete before API call...');
      await refreshPromise;
    }

    try {
      // Check if we have valid tokens (the interceptor will handle adding Authorization header)
      const savedTokenData = localStorage.getItem('dental_admin_tokens');
      if (!savedTokenData) {
        throw new Error('No authentication token available - please login');
      }

      let currentTokenData;
      try {
        currentTokenData = JSON.parse(savedTokenData);
      } catch (error) {
        console.error('Invalid token data in localStorage');
        localStorage.removeItem('dental_admin_tokens');
        throw new Error('Invalid token data - please login again');
      }

      if (!currentTokenData.access_token) {
        throw new Error('No access token available - please login');
      }

      // Check if token is about to expire and refresh if needed (but only if not already refreshing)
      const timeUntilExpiry = currentTokenData.expires_at - Date.now();
      if (timeUntilExpiry <= 120000 && !isRefreshing) { // Less than 2 minutes left
        console.log('Token expiring soon, refreshing before API call...');
        const refreshSuccess = await refreshAccessToken(currentTokenData.refresh_token);
        if (!refreshSuccess) {
          throw new Error('Token refresh failed');
        }
      }

      // Prepare config (Authorization header will be added by interceptor)
      const requestConfig = {
        headers: {
          ...config.headers
        },
        ...config
      };

      // For FormData, don't set Content-Type header (let axios handle it)
      if (data instanceof FormData) {
        if (requestConfig.headers['Content-Type']) {
          delete requestConfig.headers['Content-Type'];
        }
      } else if (typeof data === 'object' && data !== null) {
        // For JSON data, ensure Content-Type is set
        if (!requestConfig.headers['Content-Type']) {
          requestConfig.headers['Content-Type'] = 'application/json';
        }
      }

      console.log(`API Call: ${method.toUpperCase()} ${url}`, { 
        dataType: data instanceof FormData ? 'FormData' : typeof data,
        tokenExpiry: new Date(currentTokenData.expires_at).toISOString(),
        timeUntilExpiry: Math.floor(timeUntilExpiry / 1000) + 's'
      });

      let response;
      if (method === 'get') {
        response = await axios.get(url, requestConfig);
      } else if (method === 'post') {
        response = await axios.post(url, data, requestConfig);
      } else if (method === 'delete') {
        response = await axios.delete(url, requestConfig);
      }
      
      return response;
    } catch (error) {
      console.error('API Call error:', error);
      
      // Handle 401 errors with token refresh retry (only once per call)
      if (error.response?.status === 401 && retryCount === 0 && !isRefreshing) {
        console.log('Received 401, attempting token refresh and retry...');
        
        const savedTokenData = localStorage.getItem('dental_admin_tokens');
        if (savedTokenData) {
          try {
            const currentTokenData = JSON.parse(savedTokenData);
            if (currentTokenData.refresh_token) {
              const refreshSuccess = await refreshAccessToken(currentTokenData.refresh_token);
              if (refreshSuccess) {
                // Wait a bit before retry to ensure token is fully updated
                await new Promise(resolve => setTimeout(resolve, 100));
                // Retry the original request with new token
                return apiCall(method, url, data, config, 1);
              }
            }
          } catch (parseError) {
            console.error('Error parsing token data during retry:', parseError);
          }
        }
        
        // If refresh failed or no refresh token, logout
        console.error('Authentication failed, logging out');
        setAuthError('Session expired. Please login again.');
        logout();
        throw new Error('Authentication failed');
      }
      
      throw error;
    }
  };

  const loadData = async () => {
    // Check if we have authentication before attempting to load data
    const savedTokenData = localStorage.getItem('dental_admin_tokens');
    if (!savedTokenData) {
      console.log('No tokens available for loading data');
      return;
    }

    try {
      setLoading(prev => ({ ...prev, data: true }));
      setError(''); // Clear any previous errors
      
      const [locationsRes, patientsRes, doctorsRes, nursesRes, liveRes] = await Promise.all([
        apiCall('get', `${API}/locations`),
        apiCall('get', `${API}/patients?location=${selectedLocation}`),
        apiCall('get', `${API}/staff?location=${selectedLocation}&role=doctor`),
        apiCall('get', `${API}/staff?location=${selectedLocation}&role=nurse`),
        apiCall('get', `${API}/live/${selectedLocation}`)
      ]);

      setLocations(locationsRes.data);
      setPatients(patientsRes.data);
      setDoctors(doctorsRes.data);
      setNurses(nursesRes.data);
      setLiveState(liveRes.data);
      
      // Update music form with current state
      setMusicForm(prev => ({ 
        ...prev, 
        youtubeUrl: liveRes.data.music_url || '',
        muted: liveRes.data.music_muted ?? true
      }));
    } catch (error) {
      console.error('Failed to load data:', error);
      if (error.message.includes('authentication') || error.message.includes('login')) {
        setAuthError('Authentication required. Please login.');
        setIsAuthenticated(false);
      } else {
        setError('Failed to load data. Please refresh the page.');
      }
    } finally {
      setLoading(prev => ({ ...prev, data: false }));
    }
  };

  const addPatient = async (e) => {
    e.preventDefault();
    if (!patientForm.name.trim()) return;

    try {
      setLoading(prev => ({ ...prev, addPatient: true }));
      const formData = new FormData();
      formData.append('locationSlug', selectedLocation);
      formData.append('name', patientForm.name);
      if (patientForm.note) formData.append('note', patientForm.note);

      await apiCall('post', `${API}/patients`, formData);
      setPatientForm({ name: '', note: '' });
      await loadData();
      setSuccess('Patient added successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError('Failed to add patient');
    } finally {
      setLoading(prev => ({ ...prev, addPatient: false }));
    }
  };

  const addStaff = async (e, role) => {
    e.preventDefault();
    const form = role === 'doctor' ? doctorForm : nurseForm;
    const setForm = role === 'doctor' ? setDoctorForm : setNurseForm;
    
    if (!form.name.trim()) return;

    try {
      setLoading(prev => ({ ...prev, [`add${role}`]: true }));
      const formData = new FormData();
      formData.append('locationSlug', selectedLocation);
      formData.append('role', role);
      formData.append('name', form.name);

      await apiCall('post', `${API}/staff`, formData);
      setForm({ name: '' });
      await loadData();
      setSuccess(`${role.charAt(0).toUpperCase() + role.slice(1)} added successfully!`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError(`Failed to add ${role}`);
    } finally {
      setLoading(prev => ({ ...prev, [`add${role}`]: false }));
    }
  };

  const uploadPhoto = async (staffId, file) => {
    try {
      setLoading(prev => ({ ...prev, [`upload_${staffId}`]: true }));
      const formData = new FormData();
      formData.append('file', file);

      await apiCall('post', `${API}/staff/${staffId}/photo`, formData);
      
      await loadData();
      setSuccess('Photo uploaded successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError('Failed to upload photo');
    } finally {
      setLoading(prev => ({ ...prev, [`upload_${staffId}`]: false }));
    }
  };

  const deleteItem = async (type, id) => {
    try {
      setLoading(prev => ({ ...prev, [`delete_${id}`]: true }));
      await apiCall('delete', `${API}/${type}/${id}`);
      await loadData();
      setSuccess(`${type.slice(0, -1).charAt(0).toUpperCase() + type.slice(1, -1)} deleted successfully!`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      setError(`Failed to delete ${type.slice(0, -1)}`);
    } finally {
      setLoading(prev => ({ ...prev, [`delete_${id}`]: false }));
    }
  };

  const goLive = async (type, id) => {
    try {
      setLoading(prev => ({ ...prev, [`live_${type}_${id}`]: true }));
      const updateData = { [`${type}_id`]: id };
      await apiCall('post', `${API}/live/${selectedLocation}`, updateData);
      await loadData();
    } catch (error) {
      setError(`Failed to go live with ${type}`);
    } finally {
      setLoading(prev => ({ ...prev, [`live_${type}_${id}`]: false }));
    }
  };

  const clearName = async () => {
    try {
      setLoading(prev => ({ ...prev, clearName: true }));
      await apiCall('post', `${API}/live/${selectedLocation}/clear-name`);
    } catch (error) {
      setError('Failed to clear name');
    } finally {
      setLoading(prev => ({ ...prev, clearName: false }));
    }
  };

  const resetPhotos = async () => {
    try {
      setLoading(prev => ({ ...prev, resetPhotos: true }));
      await apiCall('post', `${API}/live/${selectedLocation}/reset-photos`);
    } catch (error) {
      setError('Failed to reset photos');
    } finally {
      setLoading(prev => ({ ...prev, resetPhotos: false }));
    }
  };

  const setMusic = async () => {
    if (!musicForm.youtubeUrl.trim()) {
      setError('Please enter a YouTube URL');
      return;
    }

    try {
      setLoading(prev => ({ ...prev, setMusic: true }));
      
      const response = await apiCall('post', `${API}/live/${selectedLocation}/set-music`, {
        youtube_url: musicForm.youtubeUrl.trim(),
        muted: musicForm.muted
      }, {
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response && response.status === 200) {
        setSuccess('Music set successfully!');
        setTimeout(() => setSuccess(''), 3000);
        await loadData();
      }
    } catch (error) {
      console.error('Set music error:', error);
      setError(`Failed to set music: ${error.message}`);
      setTimeout(() => setError(''), 5000);
    } finally {
      setLoading(prev => ({ ...prev, setMusic: false }));
    }
  };

  const clearMusic = async () => {
    try {
      setLoading(prev => ({ ...prev, clearMusic: true }));
      
      const response = await apiCall('post', `${API}/live/${selectedLocation}/clear-music`, null, {
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response && response.status === 200) {
        setSuccess('Music cleared successfully!');
        setTimeout(() => setSuccess(''), 3000);
        setMusicForm(prev => ({ ...prev, youtubeUrl: '' }));
        await loadData();
      }
    } catch (error) {
      console.error('Clear music error:', error);
      setError(`Failed to clear music: ${error.message}`);
      setTimeout(() => setError(''), 5000);
    } finally {
      setLoading(prev => ({ ...prev, clearMusic: false }));
    }
  };

  const isValidYouTubeUrl = (url) => {
    if (!url) return false;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11);
  };

  if (!isAuthenticated) {
    return (
      <div className="auth-overlay" data-testid="auth-overlay">
        <div className="auth-modal" data-testid="auth-modal">
          <h2 data-testid="auth-title">Admin Login</h2>
          {authError && <div className="error-message" data-testid="auth-error">{authError}</div>}
          <form onSubmit={authenticate} data-testid="auth-form">
            <div className="form-group">
              <label>Username</label>
              <input
                type="text"
                className="form-input"
                value={authCredentials.username}
                onChange={(e) => setAuthCredentials(prev => ({ ...prev, username: e.target.value }))}
                data-testid="username-input"
                required
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                className="form-input"
                value={authCredentials.password}
                onChange={(e) => setAuthCredentials(prev => ({ ...prev, password: e.target.value }))}
                data-testid="password-input"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary" style={{width: '100%'}} data-testid="login-button" disabled={loading.login}>
              {loading.login ? <span className="loading"></span> : 'Login'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-container" data-testid="admin-panel">
      <div className="admin-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
          <div>
            <h1 className="admin-title" data-testid="admin-title">Dental Clinic Admin</h1>
            <p className="admin-subtitle">Manage signage content for all locations</p>
          </div>
          <div style={{ display: 'flex', gap: '1rem', alignSelf: 'flex-start' }}>
            <button 
              className="btn btn-secondary btn-sm" 
              onClick={() => {
                const savedTokenData = localStorage.getItem('dental_admin_tokens');
                if (savedTokenData) {
                  try {
                    const tokens = JSON.parse(savedTokenData);
                    if (tokens.refresh_token) {
                      refreshAccessToken(tokens.refresh_token);
                    }
                  } catch (error) {
                    console.error('Error parsing tokens for refresh:', error);
                  }
                }
              }}
              data-testid="refresh-session-button"
              disabled={!localStorage.getItem('dental_admin_tokens')}
            >
              Refresh Session
            </button>
            <button 
              className="btn btn-secondary" 
              onClick={logout}
              data-testid="logout-button"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="admin-content">
        {/* Messages */}
        {error && <div className="error-message" data-testid="error-message">{error}</div>}
        {success && <div className="success-message" data-testid="success-message">{success}</div>}

        {/* Location Selector */}
        <div className="location-selector">
          <h3>Select Location</h3>
          <select
            className="form-input"
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
            data-testid="location-selector"
          >
            {locations.map(location => (
              <option key={location.id} value={location.slug}>
                {location.name}
              </option>
            ))}
          </select>
        </div>

        {/* Management Panels */}
        <div className="management-panels">
          {/* Patients Panel */}
          <div className="panel" data-testid="patients-panel">
            <h3><Users size={20} />Patients</h3>
            <div className="panel-content">
              <form onSubmit={addPatient}>
                <div className="form-group">
                  <label>Patient Name</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Enter patient name"
                    value={patientForm.name}
                    onChange={(e) => setPatientForm(prev => ({ ...prev, name: e.target.value }))}
                    data-testid="patient-name-input"
                  />
                </div>
                <div className="form-group">
                  <label>Note (Optional)</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Optional note"
                    value={patientForm.note}
                    onChange={(e) => setPatientForm(prev => ({ ...prev, note: e.target.value }))}
                    data-testid="patient-note-input"
                  />
                </div>
                <button 
                  type="submit" 
                  className="btn btn-primary" 
                  disabled={loading.addPatient}
                  data-testid="add-patient-button"
                >
                  {loading.addPatient ? <span className="loading"></span> : 'Add Patient'}
                </button>
              </form>

              <div className="item-list" data-testid="patients-list">
                {patients.map(patient => (
                  <div 
                    key={patient.id} 
                    className={`item ${liveState.patient?.id === patient.id ? 'active' : ''}`}
                    data-testid={`patient-item-${patient.id}`}
                  >
                    <div className="item-info">
                      <div className="item-name">{patient.name}</div>
                      {patient.note && <div className="item-note">{patient.note}</div>}
                      {liveState.patient?.id === patient.id && <div className="item-note">LIVE</div>}
                    </div>
                    <div className="item-actions">
                      <button
                        className="btn btn-success btn-sm"
                        onClick={() => goLive('patient', patient.id)}
                        disabled={loading[`live_patient_${patient.id}`]}
                        data-testid={`go-live-patient-${patient.id}`}
                      >
                        {loading[`live_patient_${patient.id}`] ? <span className="loading"></span> : <><UserCheck size={16} /> Go Live</>}
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => deleteItem('patients', patient.id)}
                        disabled={loading[`delete_${patient.id}`]}
                        data-testid={`delete-patient-${patient.id}`}
                      >
                        {loading[`delete_${patient.id}`] ? <span className="loading"></span> : <Trash2 size={16} />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Doctors Panel */}
          <div className="panel" data-testid="doctors-panel">
            <h3><UserCheck size={20} />Doctors</h3>
            <div className="panel-content">
              <form onSubmit={(e) => addStaff(e, 'doctor')}>
                <div className="form-group">
                  <label>Doctor Name</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Enter doctor name"
                    value={doctorForm.name}
                    onChange={(e) => setDoctorForm(prev => ({ ...prev, name: e.target.value }))}
                    data-testid="doctor-name-input"
                  />
                </div>
                <button 
                  type="submit" 
                  className="btn btn-primary" 
                  disabled={loading.adddoctor}
                  data-testid="add-doctor-button"
                >
                  {loading.adddoctor ? <span className="loading"></span> : 'Add Doctor'}
                </button>
              </form>

              <div className="item-list" data-testid="doctors-list">
                {doctors.map(doctor => (
                  <div 
                    key={doctor.id} 
                    className={`item ${liveState.doctor?.id === doctor.id ? 'active' : ''}`}
                    data-testid={`doctor-item-${doctor.id}`}
                  >
                    <div className="item-info">
                      <div className="item-name">{doctor.name}</div>
                      {doctor.photo_url && <img src={doctor.photo_url} alt={doctor.name} className="photo-preview" />}
                      {liveState.doctor?.id === doctor.id && <div className="item-note">LIVE</div>}
                    </div>
                    <div className="item-actions">
                      <label className="btn btn-secondary btn-sm" style={{cursor: 'pointer'}}>
                        <Upload size={16} />
                        <input
                          type="file"
                          accept="image/jpeg,image/png"
                          style={{display: 'none'}}
                          onChange={(e) => e.target.files[0] && uploadPhoto(doctor.id, e.target.files[0])}
                          data-testid={`upload-doctor-photo-${doctor.id}`}
                        />
                      </label>
                      <button
                        className="btn btn-success btn-sm"
                        onClick={() => goLive('doctor', doctor.id)}
                        disabled={loading[`live_doctor_${doctor.id}`]}
                        data-testid={`go-live-doctor-${doctor.id}`}
                      >
                        {loading[`live_doctor_${doctor.id}`] ? <span className="loading"></span> : <><UserCheck size={16} /> Go Live</>}
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => deleteItem('staff', doctor.id)}
                        disabled={loading[`delete_${doctor.id}`]}
                        data-testid={`delete-doctor-${doctor.id}`}
                      >
                        {loading[`delete_${doctor.id}`] ? <span className="loading"></span> : <Trash2 size={16} />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Nurses Panel */}
          <div className="panel" data-testid="nurses-panel">
            <h3><Users size={20} />Nurses</h3>
            <div className="panel-content">
              <form onSubmit={(e) => addStaff(e, 'nurse')}>
                <div className="form-group">
                  <label>Nurse Name</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Enter nurse name"
                    value={nurseForm.name}
                    onChange={(e) => setNurseForm(prev => ({ ...prev, name: e.target.value }))}
                    data-testid="nurse-name-input"
                  />
                </div>
                <button 
                  type="submit" 
                  className="btn btn-primary" 
                  disabled={loading.addnurse}
                  data-testid="add-nurse-button"
                >
                  {loading.addnurse ? <span className="loading"></span> : 'Add Nurse'}
                </button>
              </form>

              <div className="item-list" data-testid="nurses-list">
                {nurses.map(nurse => (
                  <div 
                    key={nurse.id} 
                    className={`item ${liveState.nurse?.id === nurse.id ? 'active' : ''}`}
                    data-testid={`nurse-item-${nurse.id}`}
                  >
                    <div className="item-info">
                      <div className="item-name">{nurse.name}</div>
                      {nurse.photo_url && <img src={nurse.photo_url} alt={nurse.name} className="photo-preview" />}
                      {liveState.nurse?.id === nurse.id && <div className="item-note">LIVE</div>}
                    </div>
                    <div className="item-actions">
                      <label className="btn btn-secondary btn-sm" style={{cursor: 'pointer'}}>
                        <Upload size={16} />
                        <input
                          type="file"
                          accept="image/jpeg,image/png"
                          style={{display: 'none'}}
                          onChange={(e) => e.target.files[0] && uploadPhoto(nurse.id, e.target.files[0])}
                          data-testid={`upload-nurse-photo-${nurse.id}`}
                        />
                      </label>
                      <button
                        className="btn btn-success btn-sm"
                        onClick={() => goLive('nurse', nurse.id)}
                        disabled={loading[`live_nurse_${nurse.id}`]}
                        data-testid={`go-live-nurse-${nurse.id}`}
                      >
                        {loading[`live_nurse_${nurse.id}`] ? <span className="loading"></span> : <><UserCheck size={16} /> Go Live</>}
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => deleteItem('staff', nurse.id)}
                        disabled={loading[`delete_${nurse.id}`]}
                        data-testid={`delete-nurse-${nurse.id}`}
                      >
                        {loading[`delete_${nurse.id}`] ? <span className="loading"></span> : <Trash2 size={16} />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Background Music Section */}
        <div className="controls-section" data-testid="music-controls-section">
          <h3>🎵 Background Music</h3>
          <div className="panel-content">
            <div className="form-group">
              <label>YouTube URL</label>
              <input
                type="url"
                className="form-input"
                placeholder="Paste YouTube URL here (e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ)"
                value={musicForm.youtubeUrl}
                onChange={(e) => setMusicForm(prev => ({ ...prev, youtubeUrl: e.target.value }))}
                data-testid="youtube-url-input"
              />
            </div>
            
            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={musicForm.muted}
                  onChange={(e) => setMusicForm(prev => ({ ...prev, muted: e.target.checked }))}
                  data-testid="mute-checkbox"
                  style={{ marginRight: '0.5rem' }}
                />
                Start Muted by Default
              </label>
            </div>

            <div className="control-buttons" style={{ gap: '1rem', marginTop: '1rem' }}>
              <button
                className="btn btn-primary"
                onClick={setMusic}
                disabled={loading.setMusic || !musicForm.youtubeUrl.trim()}
                data-testid="set-music-button"
              >
                {loading.setMusic ? <span className="loading"></span> : '🎵 Set Music'}
              </button>
              <button
                className="btn btn-secondary"
                onClick={clearMusic}
                disabled={loading.clearMusic}
                data-testid="clear-music-button"
              >
                {loading.clearMusic ? <span className="loading"></span> : '🗑️ Clear Music'}
              </button>
            </div>

            {liveState.music_url && (
              <div style={{ marginTop: '1rem', padding: '1rem', background: '#f0f8ff', borderRadius: '8px', fontSize: '0.9rem' }}>
                <strong>Current Music:</strong><br />
                <strong>Status:</strong> {liveState.music_muted ? '🔇 Muted by default' : '🔊 Unmuted'}<br />
                <strong>URL:</strong> <a href={liveState.music_url} target="_blank" rel="noopener noreferrer" style={{ wordBreak: 'break-all' }}>
                  {liveState.music_url.substring(0, 50)}...
                </a>
              </div>
            )}
          </div>
        </div>

        {/* Control Section */}
        <div className="controls-section" data-testid="controls-section">
          <h3>Display Controls</h3>
          <div className="control-buttons">
            <button
              className="btn btn-secondary"
              onClick={clearName}
              disabled={loading.clearName}
              data-testid="clear-name-button"
            >
              {loading.clearName ? <span className="loading"></span> : <><X size={16} /> Clear Name</>}
            </button>
            <button
              className="btn btn-secondary"
              onClick={resetPhotos}
              disabled={loading.resetPhotos}
              data-testid="reset-photos-button"
            >
              {loading.resetPhotos ? <span className="loading"></span> : <><RotateCcw size={16} /> Reset Photos</>}
            </button>
            <button
              className="btn btn-primary"
              onClick={() => window.open(`/display/${selectedLocation}`, '_blank')}
              data-testid="open-display-button"
            >
              <ExternalLink size={16} /> Open Display
            </button>
          </div>
        </div>
      </div>

      {/* Connection Status */}
      <div className={`connection-status ${connectionStatus}`} data-testid="connection-status">
        {connectionStatus === 'connected' ? '🟢 Connected' : '🔴 Disconnected'}
      </div>
    </div>
  );
};

export default AdminPanel;