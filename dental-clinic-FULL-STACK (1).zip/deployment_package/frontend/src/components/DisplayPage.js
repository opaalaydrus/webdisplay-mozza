import React, { useState, useEffect, useRef } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { io } from 'socket.io-client';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const DisplayPage = () => {
  const { locationSlug } = useParams();
  const [searchParams] = useSearchParams();
  const nameOverride = searchParams.get('name');

  const [liveState, setLiveState] = useState({
    patient: null,
    doctor: null,
    nurse: null,
    updated_at: null
  });
  const [location, setLocation] = useState(null);
  const [socket, setSocket] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [error, setError] = useState('');
  const [currentMusicUrl, setCurrentMusicUrl] = useState(null);
  const [musicMuted, setMusicMuted] = useState(true);

  useEffect(() => {
    loadInitialData();
    initializeSocket();

    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, [locationSlug]);

  const extractYouTubeVideoId = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const loadInitialData = async () => {
    try {
      // Load location info and initial live state
      const [locationsRes, liveRes] = await Promise.all([
        axios.get(`${API}/locations`),
        axios.get(`${API}/live/${locationSlug}`)
      ]);

      const currentLocation = locationsRes.data.find(loc => loc.slug === locationSlug);
      if (!currentLocation) {
        setError('Location not found');
        return;
      }

      setLocation(currentLocation);
      setLiveState(liveRes.data);
      
      // Update music state
      setCurrentMusicUrl(liveRes.data.music_url);
      setMusicMuted(liveRes.data.music_muted ?? true);
    } catch (error) {
      console.error('Failed to load initial data:', error);
      setError('Failed to load display data');
    }
  };

  const initializeSocket = () => {
    const newSocket = io(BACKEND_URL, {
      transports: ['websocket', 'polling']
    });

    newSocket.on('connect', () => {
      setConnectionStatus('connected');
      setError('');
      // Join room for this location
      newSocket.emit('join_room', { locationSlug });
    });

    newSocket.on('disconnect', () => {
      setConnectionStatus('disconnected');
    });

    newSocket.on('connect_error', (error) => {
      console.error('Connection error:', error);
      setConnectionStatus('error');
    });

    newSocket.on('live:init', (data) => {
      setLiveState(data);
    });

    newSocket.on('live:update', (data) => {
      setLiveState(data);
    });

    newSocket.on('music:update', (data) => {
      console.log('Music update received:', data);
      setCurrentMusicUrl(data.music_url);
      setMusicMuted(data.music_muted ?? true);
    });

    setSocket(newSocket);

    // Fallback polling every 10 seconds if WebSocket fails
    const pollInterval = setInterval(async () => {
      if (connectionStatus !== 'connected') {
        try {
          const response = await axios.get(`${API}/live/${locationSlug}`);
          setLiveState(response.data);
        } catch (error) {
          console.error('Polling failed:', error);
        }
      }
    }, 10000);

    return () => clearInterval(pollInterval);
  };

  // Simple YouTube embed component
  const renderYouTubePlayer = () => {
    if (!currentMusicUrl) return null;
    
    const videoId = extractYouTubeVideoId(currentMusicUrl);
    if (!videoId) return null;
    
    const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&loop=1&playlist=${videoId}&controls=0&showinfo=0&rel=0&iv_load_policy=3&modestbranding=1${musicMuted ? '&mute=1' : ''}`;
    
    return (
      <iframe
        src={embedUrl}
        style={{
          position: 'fixed',
          bottom: '-100px',
          left: '-100px',
          width: '1px',
          height: '1px',
          border: 'none',
          opacity: 0,
          pointerEvents: 'none'
        }}
        allow="autoplay; encrypted-media"
        title="Background Music"
        data-testid="youtube-embed"
      />
    );
  };

  if (error) {
    return (
      <div className="display-container" data-testid="display-error">
        <div className="display-content">
          <div className="patient-section">
            <div className="patient-name" style={{color: '#ff6b6b'}}>
              Error: {error}
            </div>
            <div className="patient-subtext">
              Please check your connection and try again.
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Determine patient name to display (URL override or live state)
  const displayPatientName = nameOverride || liveState.patient?.name || "Ms. Melinda";
  
  // Format location name for display
  const locationDisplayName = location?.name || `PUTIH Dental ${locationSlug.toUpperCase()}`;

  return (
    <div className="display-container" data-testid="display-page">
      {/* Staff Photos - Background */}
      <div className="staff-photos">
        {/* Doctor Photo */}
        <div className="doctor-photo" data-testid="doctor-photo">
          {liveState.doctor?.photo_url ? (
            <img
              src={liveState.doctor.photo_url}
              alt={liveState.doctor.name || 'Doctor'}
              className="doctor-image"
              data-testid="doctor-image"
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.nextSibling.style.display = 'flex';
              }}
            />
          ) : (
            <div className="placeholder-photo" data-testid="doctor-placeholder">
              D
            </div>
          )}
          {liveState.doctor?.photo_url && (
            <div 
              className="placeholder-photo" 
              style={{display: 'none'}}
              data-testid="doctor-placeholder-fallback"
            >
              D
            </div>
          )}
        </div>

        {/* Nurse Photo */}
        <div className="nurse-photo" data-testid="nurse-photo">
          {liveState.nurse?.photo_url ? (
            <img
              src={liveState.nurse.photo_url}
              alt={liveState.nurse.name || 'Nurse'}
              className="nurse-image"
              data-testid="nurse-image"
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.nextSibling.style.display = 'flex';
              }}
            />
          ) : (
            <div className="placeholder-photo" data-testid="nurse-placeholder">
              N
            </div>
          )}
          {liveState.nurse?.photo_url && (
            <div 
              className="placeholder-photo" 
              style={{display: 'none'}}
              data-testid="nurse-placeholder-fallback"
            >
              N
            </div>
          )}
        </div>
      </div>

      {/* Main Content - New Layout */}
      <div className="display-content">
        {/* Top Header */}
        <div className="display-header">
          <img 
            src="/images/mozza-logo.png" 
            alt="Mozza Dental" 
            className="display-logo"
            data-testid="display-logo"
          />
          <div className="display-tagline" data-testid="display-tagline">IMPLANT, ORTHO & AESTHETIC DENTAL CENTER</div>
        </div>

        {/* Main Center Content */}
        <div className="display-main-content">
          <div className="display-welcome" data-testid="display-welcome">WELCOME TO</div>
          <div className="display-title" data-testid="display-title">Mozza Dental {locationSlug.charAt(0).toUpperCase() + locationSlug.slice(1)}</div>
          
          <div className="patient-section">
            <div 
              className="patient-name" 
              aria-live="polite"
              data-testid="patient-name"
            >
              {displayPatientName}
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="display-footer">
          <div className="patient-subtext" data-testid="patient-subtext">
            Kindly enjoy your treatment,<br />you are in the right hands
          </div>
        </div>
      </div>

      {/* Connection Status - only show if disconnected */}
      {connectionStatus !== 'connected' && (
        <div className={`connection-status ${connectionStatus}`} data-testid="connection-status">
          {connectionStatus === 'error' ? '⚠️ Connection Error' : '🔄 Reconnecting...'}
        </div>
      )}

      {/* YouTube Background Music */}
      {renderYouTubePlayer()}

      {/* Hidden elements for debugging */}
      <div style={{position: 'absolute', top: -1000, left: -1000}}>
        <div data-testid="live-state-debug">{JSON.stringify(liveState)}</div>
        <div data-testid="location-slug-debug">{locationSlug}</div>
        <div data-testid="name-override-debug">{nameOverride || 'none'}</div>
      </div>
    </div>
  );
};

export default DisplayPage;